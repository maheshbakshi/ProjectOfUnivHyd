perl perl_script.pl w3.tr 1 2 ./cwnd3/12
perl perl_script.pl w3.tr 2 3 ./cwnd3/23
perl perl_script.pl w3.tr 2 4 ./cwnd3/24
perl perl_script.pl w3.tr 3 4 ./cwnd3/34
perl perl_script.pl w3.tr 3 5 ./cwnd3/35
perl perl_script.pl w3.tr 5 6 ./cwnd3/56
perl perl_script.pl w3.tr 7 8 ./cwnd3/78
perl perl_script.pl w3.tr 8 9 ./cwnd3/89
perl perl_script.pl w3.tr 8 10 ./cwnd3/810
perl perl_script.pl w3.tr 10 11 ./cwnd3/1011
perl perl_script.pl w3.tr 15 16 ./cwnd3/1516
perl perl_script.pl w3.tr 17 18 ./cwnd3/1718
perl perl_script.pl w3.tr 22 23 ./cwnd3/2223
perl perl_script.pl w3.tr 23 24 ./cwnd3/2324



