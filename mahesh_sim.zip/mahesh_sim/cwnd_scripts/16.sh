perl perl_script.pl w16.tr 1 2 ./cwnd16/12
perl perl_script.pl w16.tr 1 3 ./cwnd16/13
perl perl_script.pl w16.tr 2 3 ./cwnd16/23
perl perl_script.pl w16.tr 8 9 ./cwnd16/89
perl perl_script.pl w16.tr 8 10 ./cwnd16/810
perl perl_script.pl w16.tr 9 10 ./cwnd16/910
perl perl_script.pl w16.tr 10 11 ./cwnd16/1011
perl perl_script.pl w16.tr 11 12 ./cwnd16/1112
perl perl_script.pl w16.tr 11 13 ./cwnd16/1113
perl perl_script.pl w16.tr 12 13 ./cwnd16/1213
perl perl_script.pl w16.tr 12 14 ./cwnd16/1214
perl perl_script.pl w16.tr 13 14 ./cwnd16/1314
perl perl_script.pl w16.tr 14 15 ./cwnd16/1415
perl perl_script.pl w16.tr 16 17 ./cwnd16/1617
perl perl_script.pl w16.tr 18 19 ./cwnd16/1819
perl perl_script.pl w16.tr 18 20 ./cwnd16/1820
perl perl_script.pl w16.tr 19 20 ./cwnd16/1920
perl perl_script.pl w16.tr 20 21 ./cwnd16/2021
perl perl_script.pl w16.tr 22 23 ./cwnd16/2223


