perl perl_script.pl w4.tr 1 2 ./cwnd4/12
perl perl_script.pl w4.tr 1 3 ./cwnd4/13
perl perl_script.pl w4.tr 7 8 ./cwnd4/78
perl perl_script.pl w4.tr 9 10 ./cwnd4/910
perl perl_script.pl w4.tr 11 12 ./cwnd4/1112
perl perl_script.pl w4.tr 11 13 ./cwnd4/1113
perl perl_script.pl w4.tr 12 13 ./cwnd4/1213
perl perl_script.pl w4.tr 12 14 ./cwnd4/1214
perl perl_script.pl w4.tr 16 17 ./cwnd4/1617
perl perl_script.pl w4.tr 19 20 ./cwnd4/1920


