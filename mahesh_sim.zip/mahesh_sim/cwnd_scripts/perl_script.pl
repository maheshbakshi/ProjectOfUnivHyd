
$file = $ARGV[0];
print "input trace file file\n";
open (B,"$file");
$src = $ARGV[1];
$dest = $ARGV[2];
$out = $ARGV[3];
open (A,">$out.out");
print "src $src dest $dest output  file $out.out\n";

while($line = <B>) {
chop;
@ar = split(/\s+/,$line);
	if ($ar[1] == $src && $ar[3] == $dest) {
	print A "$ar[0] $ar[6]\n";
	}
}

