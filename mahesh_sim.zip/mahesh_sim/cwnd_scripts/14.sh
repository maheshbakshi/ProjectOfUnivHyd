perl perl_script.pl w14.tr 1 2 ./cwnd14/12
perl perl_script.pl w14.tr 1 3 ./cwnd14/13
perl perl_script.pl w14.tr 2 3 ./cwnd14/23
perl perl_script.pl w14.tr 8 9 ./cwnd14/89
perl perl_script.pl w14.tr 8 10 ./cwnd14/810
perl perl_script.pl w14.tr 9 10 ./cwnd14/910
perl perl_script.pl w14.tr 10 11 ./cwnd14/1011
perl perl_script.pl w14.tr 11 12 ./cwnd14/1112
perl perl_script.pl w14.tr 11 13 ./cwnd14/1113
perl perl_script.pl w14.tr 12 13 ./cwnd14/1213
perl perl_script.pl w14.tr 12 14 ./cwnd14/1214
perl perl_script.pl w14.tr 13 14 ./cwnd14/1314
perl perl_script.pl w14.tr 14 15 ./cwnd14/1415
perl perl_script.pl w14.tr 16 17 ./cwnd14/1617
perl perl_script.pl w14.tr 18 19 ./cwnd14/1819
perl perl_script.pl w14.tr 18 20 ./cwnd14/1820
perl perl_script.pl w14.tr 19 20 ./cwnd14/1920
perl perl_script.pl w14.tr 20 21 ./cwnd14/2021
perl perl_script.pl w14.tr 22 23 ./cwnd14/2223


