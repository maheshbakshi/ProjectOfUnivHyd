perl perl_script.pl w12.tr 1 2 ./cwnd12/12
perl perl_script.pl w12.tr 1 3 ./cwnd12/13
perl perl_script.pl w12.tr 2 3 ./cwnd12/23
perl perl_script.pl w12.tr 8 9 ./cwnd12/89
perl perl_script.pl w12.tr 8 10 ./cwnd12/810
perl perl_script.pl w12.tr 9 10 ./cwnd12/910
perl perl_script.pl w12.tr 10 11 ./cwnd12/1011
perl perl_script.pl w12.tr 11 12 ./cwnd12/1112
perl perl_script.pl w12.tr 11 13 ./cwnd12/1113
perl perl_script.pl w12.tr 12 13 ./cwnd12/1213
perl perl_script.pl w12.tr 12 14 ./cwnd12/1214
perl perl_script.pl w12.tr 13 14 ./cwnd12/1314
perl perl_script.pl w12.tr 14 15 ./cwnd12/1415
perl perl_script.pl w12.tr 16 17 ./cwnd12/1617
perl perl_script.pl w12.tr 18 19 ./cwnd12/1819
perl perl_script.pl w12.tr 18 20 ./cwnd12/1820
perl perl_script.pl w12.tr 19 20 ./cwnd12/1920
perl perl_script.pl w12.tr 20 21 ./cwnd12/2021
perl perl_script.pl w12.tr 22 23 ./cwnd12/2223


