perl perl_script.pl w11.tr 1 2 ./cwnd11/12
perl perl_script.pl w11.tr 1 3 ./cwnd11/13
perl perl_script.pl w11.tr 2 3 ./cwnd11/23
perl perl_script.pl w11.tr 8 9 ./cwnd11/89
perl perl_script.pl w11.tr 8 10 ./cwnd11/810
perl perl_script.pl w11.tr 9 10 ./cwnd11/910
perl perl_script.pl w11.tr 9 11 ./cwnd11/911
perl perl_script.pl w11.tr 10 11 ./cwnd11/1011
perl perl_script.pl w11.tr 11 12 ./cwnd11/1112
perl perl_script.pl w11.tr 11 13 ./cwnd11/1113


