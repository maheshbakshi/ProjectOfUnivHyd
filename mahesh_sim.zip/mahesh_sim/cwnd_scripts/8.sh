perl perl_script.pl w8.tr 1 2 ./cwnd8/12
perl perl_script.pl w8.tr 1 3 ./cwnd8/13
perl perl_script.pl w8.tr 7 8 ./cwnd8/78
perl perl_script.pl w8.tr 9 10 ./cwnd8/910
perl perl_script.pl w8.tr 11 12 ./cwnd8/1112
perl perl_script.pl w8.tr 11 13 ./cwnd8/1113
perl perl_script.pl w8.tr 12 13 ./cwnd8/1213
perl perl_script.pl w8.tr 12 14 ./cwnd8/1214
perl perl_script.pl w8.tr 16 17 ./cwnd8/1617
perl perl_script.pl w8.tr 19 20 ./cwnd8/1920


