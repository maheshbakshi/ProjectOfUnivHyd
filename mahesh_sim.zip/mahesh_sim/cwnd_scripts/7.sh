perl perl_script.pl w7.tr 1 2 ./cwnd7/12
perl perl_script.pl w7.tr 1 3 ./cwnd7/13
perl perl_script.pl w7.tr 7 8 ./cwnd7/78
perl perl_script.pl w7.tr 9 10 ./cwnd7/910
perl perl_script.pl w7.tr 11 12 ./cwnd7/1112
perl perl_script.pl w7.tr 11 13 ./cwnd7/1113
perl perl_script.pl w7.tr 12 13 ./cwnd7/1213
perl perl_script.pl w7.tr 12 14 ./cwnd7/1214
perl perl_script.pl w7.tr 16 17 ./cwnd7/1617
perl perl_script.pl w7.tr 19 20 ./cwnd7/1920


