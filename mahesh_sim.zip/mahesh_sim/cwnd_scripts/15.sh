perl perl_script.pl w15.tr 1 2 ./cwnd15/12
perl perl_script.pl w15.tr 1 3 ./cwnd15/13
perl perl_script.pl w15.tr 2 3 ./cwnd15/23
perl perl_script.pl w15.tr 8 9 ./cwnd15/89
perl perl_script.pl w15.tr 8 10 ./cwnd15/810
perl perl_script.pl w15.tr 9 10 ./cwnd15/910
perl perl_script.pl w15.tr 9 11 ./cwnd15/911
perl perl_script.pl w15.tr 10 11 ./cwnd15/1011
perl perl_script.pl w15.tr 11 12 ./cwnd15/1112
perl perl_script.pl w15.tr 11 13 ./cwnd15/1113


