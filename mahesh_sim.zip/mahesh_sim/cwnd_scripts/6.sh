perl perl_script.pl w6.tr1 2 ./cwnd6/12
perl perl_script.pl w6.tr2 3 ./cwnd6/23
perl perl_script.pl w6.tr2 4 ./cwnd6/24
perl perl_script.pl w6.tr3 4 ./cwnd6/34
perl perl_script.pl w6.tr3 5 ./cwnd6/35
perl perl_script.pl w6.tr5 6 ./cwnd6/56
perl perl_script.pl w6.tr7 8 ./cwnd6/78
perl perl_script.pl w6.tr8 9 ./cwnd6/89
perl perl_script.pl w6.tr8 10 ./cwnd6/810
perl perl_script.pl w6.tr10 11 ./cwnd6/1011
perl perl_script.pl w6.tr15 16 ./cwnd6/1516
perl perl_script.pl w6.tr17 18 ./cwnd6/1718
perl perl_script.pl w6.tr22 23 ./cwnd6/2223
perl perl_script.pl w6.tr23 24 ./cwnd6/2324



