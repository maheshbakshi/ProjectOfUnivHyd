perl perl_script.pl w13.tr 1 2 ./cwnd13/12
perl perl_script.pl w13.tr 1 3 ./cwnd13/13
perl perl_script.pl w13.tr 2 3 ./cwnd13/23
perl perl_script.pl w13.tr 8 9 ./cwnd13/89
perl perl_script.pl w13.tr 8 10 ./cwnd13/810
perl perl_script.pl w13.tr 9 10 ./cwnd13/910
perl perl_script.pl w13.tr 9 11 ./cwnd13/911
perl perl_script.pl w13.tr 10 11 ./cwnd13/1011
perl perl_script.pl w13.tr 11 12 ./cwnd13/1112
perl perl_script.pl w13.tr 11 13 ./cwnd13/1113


