perl perl_script.pl w5.tr 1 2 ./cwnd5/12
perl perl_script.pl w5.tr 1 3 ./cwnd5/13
perl perl_script.pl w5.tr 7 8 ./cwnd5/78
perl perl_script.pl w5.tr 9 10 ./cwnd5/910
perl perl_script.pl w5.tr 11 12 ./cwnd5/1112
perl perl_script.pl w5.tr 11 13 ./cwnd5/1113
perl perl_script.pl w5.tr 12 13 ./cwnd5/1213
perl perl_script.pl w5.tr 12 14 ./cwnd5/1214
perl perl_script.pl w5.tr 16 17 ./cwnd5/1617
perl perl_script.pl w5.tr 19 20 ./cwnd5/1920


